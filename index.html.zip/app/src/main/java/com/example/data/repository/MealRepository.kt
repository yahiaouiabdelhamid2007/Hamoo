package com.example.data.repository

import com.example.data.local.MealDao
import com.example.data.local.MealEntity
import kotlinx.coroutines.flow.Flow

class MealRepository(private val mealDao: MealDao) {
    val allMeals: Flow<List<MealEntity>> = mealDao.getAllMeals()

    fun getMealsForDateRange(startTime: Long, endTime: Long): Flow<List<MealEntity>> {
        return mealDao.getMealsBetween(startTime, endTime)
    }

    suspend fun insertMeal(meal: MealEntity): Long {
        return mealDao.insertMeal(meal)
    }

    suspend fun deleteMeal(meal: MealEntity) {
        mealDao.deleteMeal(meal)
    }

    suspend fun clearAllMeals() {
        mealDao.clearAll()
    }
}
