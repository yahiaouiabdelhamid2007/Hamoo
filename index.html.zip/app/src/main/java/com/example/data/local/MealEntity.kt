package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "meals")
data class MealEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val nameAr: String,
    val nameEn: String,
    val calories: Int,
    val proteinGrams: Float,
    val carbsGrams: Float,
    val fatGrams: Float,
    val fiberGrams: Float,
    val servingSize: String,
    val healthRating: String,
    val healthAdvice: String,
    val ingredientsJson: String,
    val imageBase64: String?,
    val mealType: String, // "فطور", "غداء", "عشاء", "وجبة خفيفة"
    val timestamp: Long = System.currentTimeMillis()
)
