package com.example.data.model

data class SampleFoodPreset(
    val id: String,
    val titleAr: String,
    val titleEn: String,
    val emoji: String,
    val calories: Int,
    val defaultServing: String,
    val protein: Float,
    val carbs: Float,
    val fat: Float,
    val fiber: Float,
    val healthScore: String,
    val advice: String,
    val mealType: String,
    val ingredients: List<IngredientItem>
)

object SampleFoodPresets {
    val presets = listOf(
        SampleFoodPreset(
            id = "preset_salad",
            titleAr = "سلطة كينوا وسالمون وأفوكادو",
            titleEn = "Salmon & Avocado Quinoa Bowl",
            emoji = "🥗",
            calories = 520,
            defaultServing = "صحن متوسط (350 غرام)",
            protein = 36f,
            carbs = 32f,
            fat = 22f,
            fiber = 8f,
            healthScore = "9.5/10 - ممتازة جداً وغنية بأوميغا 3",
            advice = "وجبة صحية متكاملة تدعم صحة القلب وتمدك بالطاقة المستدامة والشبع الطويل.",
            mealType = "غداء",
            ingredients = listOf(
                IngredientItem("فيليه سلمون طازج مشوي", 240, "150 غرام"),
                IngredientItem("كينوا عضوية مسلوقة", 140, "100 غرام"),
                IngredientItem("شرائح أفوكادو ناضج", 100, "نصف حبة"),
                IngredientItem("ورقيات خضراء وزيت زيتون بكر", 40, "طبق جانبي")
            )
        ),
        SampleFoodPreset(
            id = "preset_kabsa",
            titleAr = "كبسة دجاج بالأرز والمكسرات",
            titleEn = "Chicken Kabsa Rice",
            emoji = "🍗",
            calories = 680,
            defaultServing = "وجبة فردية (400 غرام)",
            protein = 42f,
            carbs = 68f,
            fat = 20f,
            fiber = 4f,
            healthScore = "7.8/10 - غنية بالبروتين والطاقة",
            advice = "وجبة شهية ومغذية، ينصح بتناولها في وجبة الغداء مع طبق سلطة خضراء لزيادة الألياف.",
            mealType = "غداء",
            ingredients = listOf(
                IngredientItem("صدر دجاج محمر", 260, "200 غرام"),
                IngredientItem("أرز بسمتي فاخر مبهر", 320, "200 غرام"),
                IngredientItem("لوز وصنوبر محمص", 70, "ملعقة كبيرة"),
                IngredientItem("دقوس وبهارات عربية", 30, "حسب الرغبة")
            )
        ),
        SampleFoodPreset(
            id = "preset_toast",
            titleAr = "توست أفوكادو وبيض مسلوق",
            titleEn = "Avocado Toast & Eggs",
            emoji = "🥑",
            calories = 390,
            defaultServing = "شريحتان توست (220 غرام)",
            protein = 22f,
            carbs = 28f,
            fat = 18f,
            fiber = 6.5f,
            healthScore = "9/10 - فطور متوازن ونشيط",
            advice = "خيار مثالي لبداية صباحك، يمنحك تركيزاً عالياً بفضل الدهون الأحادية غير المشبعة والبروتين النقي.",
            mealType = "فطور",
            ingredients = listOf(
                IngredientItem("بيضتان مسلوقتان", 140, "حبتان"),
                IngredientItem("توست حبوب كاملة", 150, "شريحتان"),
                IngredientItem("أفوكادو مهروس مع ليمون", 85, "نصف حبة"),
                IngredientItem("رشة بذور شيا وفلفل أسود", 15, "بهارات صحية")
            )
        ),
        SampleFoodPreset(
            id = "preset_shawarma",
            titleAr = "صحن شاورما لحم مشوي مع الحمص",
            titleEn = "Lean Beef Shawarma Plate",
            emoji = "🥩",
            calories = 580,
            defaultServing = "طبق شاورما عربي (320 غرام)",
            protein = 44f,
            carbs = 38f,
            fat = 24f,
            fiber = 5f,
            healthScore = "8/10 - غني بالحديد والبروتين",
            advice = "وجبة مشبعة جداً، ممتازة بعد التمرين الرياضي لترميم الأنسجة العضلية.",
            mealType = "عشاء",
            ingredients = listOf(
                IngredientItem("لحم عجل مشوي خالي الدهن", 330, "180 غرام"),
                IngredientItem("حمص ناعم بزيت الزيتون", 150, "ملعقتان كبيرتان"),
                IngredientItem("خبز صاج خفيف", 80, "نصف رغيف"),
                IngredientItem("بقدونس وبصل وسماق", 20, "تشكيلة خضار")
            )
        ),
        SampleFoodPreset(
            id = "preset_oats",
            titleAr = "وعاء الشوفان بالحليب والفواكه",
            titleEn = "Oatmeal with Berries & Nuts",
            emoji = "🥣",
            calories = 340,
            defaultServing = "زبدية متوسطة (260 غرام)",
            protein = 16f,
            carbs = 52f,
            fat = 8f,
            fiber = 9f,
            healthScore = "9.2/10 - غني جداً بالألياف الطبيعية",
            advice = "وجبة ممتازة لخفض الكوليسترول وتنظيم سكر الدم والشعور بالراحة الهضمية.",
            mealType = "فطور",
            ingredients = listOf(
                IngredientItem("رقائق شوفان كاملة مطبوخة", 180, "60 غرام جاف"),
                IngredientItem("حليب لوز غير محلى", 40, "كوب صغير"),
                IngredientItem("توت بري وفراولة", 50, "نصف كوب"),
                IngredientItem("عسل طبيعي ومكسرات", 70, "ملعقة صغيرة")
            )
        )
    )
}
