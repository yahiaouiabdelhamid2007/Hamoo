package com.example.data.model

data class IngredientItem(
    val name: String,
    val calories: Int,
    val portion: String = ""
)

data class FoodAnalysisResult(
    val foodNameAr: String,
    val foodNameEn: String,
    val calories: Int,
    val servingSize: String,
    val proteinGrams: Float,
    val carbsGrams: Float,
    val fatGrams: Float,
    val fiberGrams: Float,
    val healthRating: String,
    val healthAdvice: String,
    val ingredients: List<IngredientItem> = emptyList(),
    val recommendedMealType: String = "غداء"
)
