package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Nutrition & Calorie Palette
val EmeraldPrimaryLight = Color(0xFF1E7E4C)
val EmeraldPrimaryDark = Color(0xFF4ADE80)

val TealSecondaryLight = Color(0xFF0D9488)
val TealSecondaryDark = Color(0xFF2DD4BF)

val AmberTertiaryLight = Color(0xFFD97706)
val AmberTertiaryDark = Color(0xFFFBBF24)

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)

val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val SurfaceVariantDark = Color(0xFF334155)

// Macro specific colors
val ColorCalories = Color(0xFFEA580C)
val ColorProtein = Color(0xFF2563EB)
val ColorCarbs = Color(0xFFD97706)
val ColorFat = Color(0xFFDB2777)
val ColorFiber = Color(0xFF059669)

