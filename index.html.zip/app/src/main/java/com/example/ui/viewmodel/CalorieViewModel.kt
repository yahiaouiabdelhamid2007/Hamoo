package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.GeminiFoodAnalyzer
import com.example.data.local.FoodDatabase
import com.example.data.local.MealEntity
import com.example.data.model.FoodAnalysisResult
import com.example.data.model.IngredientItem
import com.example.data.model.SampleFoodPreset
import com.example.data.model.SampleFoodPresets
import com.example.data.repository.MealRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class DailyNutritionSummary(
    val totalCalories: Int = 0,
    val totalProtein: Float = 0f,
    val totalCarbs: Float = 0f,
    val totalFat: Float = 0f,
    val totalFiber: Float = 0f,
    val remainingCalories: Int = 2000,
    val progressFraction: Float = 0f
)

class CalorieViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: MealRepository
    private val prefs = application.getSharedPreferences("calorie_prefs", Context.MODE_PRIVATE)

    private val _dailyGoal = MutableStateFlow(prefs.getInt("daily_goal", 2200))
    val dailyGoal: StateFlow<Int> = _dailyGoal.asStateFlow()

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _currentAnalysis = MutableStateFlow<FoodAnalysisResult?>(null)
    val currentAnalysis: StateFlow<FoodAnalysisResult?> = _currentAnalysis.asStateFlow()

    private val _currentBitmap = MutableStateFlow<Bitmap?>(null)
    val currentBitmap: StateFlow<Bitmap?> = _currentBitmap.asStateFlow()

    private val _selectedMealFilter = MutableStateFlow("الكل")
    val selectedMealFilter: StateFlow<String> = _selectedMealFilter.asStateFlow()

    private val _selectedMealForDetail = MutableStateFlow<MealEntity?>(null)
    val selectedMealForDetail: StateFlow<MealEntity?> = _selectedMealForDetail.asStateFlow()

    private val _showGoalDialog = MutableStateFlow(false)
    val showGoalDialog: StateFlow<Boolean> = _showGoalDialog.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    val allMeals: StateFlow<List<MealEntity>>

    val todaySummary: StateFlow<DailyNutritionSummary>

    init {
        val database = FoodDatabase.getDatabase(application)
        repository = MealRepository(database.mealDao())

        allMeals = repository.allMeals.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        todaySummary = combine(allMeals, _dailyGoal) { meals, goal ->
            val startOfDay = getStartOfDayTimestamp()
            val todayMeals = meals.filter { it.timestamp >= startOfDay }

            val totalCals = todayMeals.sumOf { it.calories }
            val totalProtein = todayMeals.sumOf { it.proteinGrams.toDouble() }.toFloat()
            val totalCarbs = todayMeals.sumOf { it.carbsGrams.toDouble() }.toFloat()
            val totalFat = todayMeals.sumOf { it.fatGrams.toDouble() }.toFloat()
            val totalFiber = todayMeals.sumOf { it.fiberGrams.toDouble() }.toFloat()

            val remaining = (goal - totalCals).coerceAtLeast(0)
            val progress = if (goal > 0) (totalCals.toFloat() / goal.toFloat()).coerceIn(0f, 1f) else 0f

            DailyNutritionSummary(
                totalCalories = totalCals,
                totalProtein = totalProtein,
                totalCarbs = totalCarbs,
                totalFat = totalFat,
                totalFiber = totalFiber,
                remainingCalories = remaining,
                progressFraction = progress
            )
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = DailyNutritionSummary()
        )

        // Populate starter meal if database is empty for immediate demonstration
        seedInitialMealsIfEmpty()
    }

    private fun getStartOfDayTimestamp(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    private fun seedInitialMealsIfEmpty() {
        viewModelScope.launch {
            val hasSeeded = prefs.getBoolean("has_seeded_sample", false)
            if (!hasSeeded) {
                // Add a sample breakfast and healthy snack
                val toastPreset = SampleFoodPresets.presets.firstOrNull { it.id == "preset_toast" }
                if (toastPreset != null) {
                    val entity = MealEntity(
                        nameAr = toastPreset.titleAr,
                        nameEn = toastPreset.titleEn,
                        calories = toastPreset.calories,
                        proteinGrams = toastPreset.protein,
                        carbsGrams = toastPreset.carbs,
                        fatGrams = toastPreset.fat,
                        fiberGrams = toastPreset.fiber,
                        servingSize = toastPreset.defaultServing,
                        healthRating = toastPreset.healthScore,
                        healthAdvice = toastPreset.advice,
                        ingredientsJson = serializeIngredients(toastPreset.ingredients),
                        imageBase64 = null,
                        mealType = toastPreset.mealType,
                        timestamp = System.currentTimeMillis() - (4 * 3600 * 1000) // 4 hours ago
                    )
                    repository.insertMeal(entity)
                    prefs.edit().putBoolean("has_seeded_sample", true).apply()
                }
            }
        }
    }

    fun analyzeImage(bitmap: Bitmap) {
        _currentBitmap.value = bitmap
        _isAnalyzing.value = true
        _errorMessage.value = null

        viewModelScope.launch {
            try {
                val result = GeminiFoodAnalyzer.analyzeFood(bitmap)
                if (result.isSuccess) {
                    _currentAnalysis.value = result.getOrNull()
                } else {
                    _errorMessage.value = result.exceptionOrNull()?.message ?: "حدث خطأ أثناء التحليل"
                }
            } catch (e: Exception) {
                _errorMessage.value = e.message ?: "تعذر تحليل الصورة"
            } finally {
                _isAnalyzing.value = false
            }
        }
    }

    fun selectPresetDish(preset: SampleFoodPreset) {
        // Create an illustrative bitmap for preset
        val bitmap = createEmojiDishBitmap(preset.emoji, preset.titleAr)
        _currentBitmap.value = bitmap
        _currentAnalysis.value = FoodAnalysisResult(
            foodNameAr = preset.titleAr,
            foodNameEn = preset.titleEn,
            calories = preset.calories,
            servingSize = preset.defaultServing,
            proteinGrams = preset.protein,
            carbsGrams = preset.carbs,
            fatGrams = preset.fat,
            fiberGrams = preset.fiber,
            healthRating = preset.healthScore,
            healthAdvice = preset.advice,
            ingredients = preset.ingredients,
            recommendedMealType = preset.mealType
        )
    }

    private fun createEmojiDishBitmap(emoji: String, title: String): Bitmap {
        val size = 512
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(240, 248, 244)
            style = Paint.Style.FILL
        }
        canvas.drawRect(0f, 0f, size.toFloat(), size.toFloat(), paint)

        val circlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(220, 240, 230)
            style = Paint.Style.FILL
        }
        canvas.drawCircle(size / 2f, size / 2f, size * 0.42f, circlePaint)

        val emojiPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = 140f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(emoji, size / 2f, size / 2f + 40f, emojiPaint)
        return bitmap
    }

    fun saveCurrentMeal(mealTypeOverride: String? = null) {
        val analysis = _currentAnalysis.value ?: return
        val bitmap = _currentBitmap.value
        val mealType = mealTypeOverride ?: analysis.recommendedMealType

        viewModelScope.launch {
            val base64 = bitmap?.let { GeminiFoodAnalyzer.bitmapToBase64(it) }
            val entity = MealEntity(
                nameAr = analysis.foodNameAr,
                nameEn = analysis.foodNameEn,
                calories = analysis.calories,
                proteinGrams = analysis.proteinGrams,
                carbsGrams = analysis.carbsGrams,
                fatGrams = analysis.fatGrams,
                fiberGrams = analysis.fiberGrams,
                servingSize = analysis.servingSize,
                healthRating = analysis.healthRating,
                healthAdvice = analysis.healthAdvice,
                ingredientsJson = serializeIngredients(analysis.ingredients),
                imageBase64 = base64,
                mealType = mealType,
                timestamp = System.currentTimeMillis()
            )
            repository.insertMeal(entity)
            dismissAnalysis()
        }
    }

    fun deleteMeal(meal: MealEntity) {
        viewModelScope.launch {
            repository.deleteMeal(meal)
            if (_selectedMealForDetail.value?.id == meal.id) {
                _selectedMealForDetail.value = null
            }
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAllMeals()
        }
    }

    fun dismissAnalysis() {
        _currentAnalysis.value = null
        _currentBitmap.value = null
        _isAnalyzing.value = false
        _errorMessage.value = null
    }

    fun setFilter(filter: String) {
        _selectedMealFilter.value = filter
    }

    fun openDetail(meal: MealEntity?) {
        _selectedMealForDetail.value = meal
    }

    fun toggleGoalDialog(show: Boolean) {
        _showGoalDialog.value = show
    }

    fun updateGoal(newGoal: Int) {
        val validGoal = newGoal.coerceIn(800, 8000)
        _dailyGoal.value = validGoal
        prefs.edit().putInt("daily_goal", validGoal).apply()
        _showGoalDialog.value = false
    }

    fun clearErrorMessage() {
        _errorMessage.value = null
    }

    private fun serializeIngredients(list: List<IngredientItem>): String {
        val array = JSONArray()
        list.forEach { item ->
            val obj = JSONObject().apply {
                put("name", item.name)
                put("calories", item.calories)
                put("portion", item.portion)
            }
            array.put(obj)
        }
        return array.toString()
    }

    fun parseIngredientsJson(jsonStr: String): List<IngredientItem> {
        val list = mutableListOf<IngredientItem>()
        try {
            val array = JSONArray(jsonStr)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    IngredientItem(
                        name = obj.optString("name", ""),
                        calories = obj.optInt("calories", 0),
                        portion = obj.optString("portion", "")
                    )
                )
            }
        } catch (e: Exception) {
            // Ignore parsing error
        }
        return list
    }
}
